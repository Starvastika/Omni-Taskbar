# IANA versions like 2020a are not valid PEP 440 identifiers; the recommended
# way to translate the version is to use YYYY.n where `n` is a 0-based index.
__version__ = "2026.3"

# This exposes the original IANA version number.
IANA_VERSION = "2026c"
